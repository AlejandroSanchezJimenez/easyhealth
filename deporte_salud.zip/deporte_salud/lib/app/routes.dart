import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../features/auth/auth_providers.dart';
import '../features/auth/presentation/login_page.dart';
import '../features/diseases/presentation/explore_page.dart';
import '../features/profile/presentation/profile_page.dart';
import '../features/streak/presentation/home_page.dart';
import '../features/streak/presentation/progress_page.dart';
import '../features/teacher/presentation/teacher_page.dart';
import '../shared/widgets/home_shell.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final auth = ref.watch(authStateProvider);
  return GoRouter(
    initialLocation: '/home',
    redirect: (context, state) {
      if (auth.isLoading) return null;
      final user = auth.valueOrNull;
      final loc = state.matchedLocation;
      if (user == null) return loc == '/login' ? null : '/login';
      if (loc == '/login') return '/home';
      // Guardia de UI. La seguridad real está en Firestore/Storage Rules.
      if (loc.startsWith('/teacher') && !user.role.canManageContent) return '/home';
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
      GoRoute(path: '/teacher', builder: (_, __) => const TeacherPage()),
      StatefulShellRoute.indexedStack(
        builder: (_, __, shell) => HomeShell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: '/home', builder: (_, __) => const HomePage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/explore', builder: (_, __) => const ExplorePage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/progress', builder: (_, __) => const ProgressPage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/profile', builder: (_, __) => const ProfilePage())]),
        ],
      ),
    ],
  );
});
