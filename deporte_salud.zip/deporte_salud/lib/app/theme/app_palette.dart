import 'package:flutter/material.dart';

/// ÚNICO archivo donde se escriben valores de color.
class AppPalette {
  const AppPalette({
    required this.primary,
    required this.onPrimary,
    required this.secondary,
    required this.background,
    required this.surface,
    required this.onSurface,
    required this.error,
    required this.success,
    required this.warning,
    required this.streak,
  });

  final Color primary, onPrimary, secondary;
  final Color background, surface, onSurface;
  final Color error, success, warning;
  final Color streak;

  static const light = AppPalette(
    primary: Color(0xFF2E7D6B),
    onPrimary: Color(0xFFFFFFFF),
    secondary: Color(0xFF5B8DEF),
    background: Color(0xFFF7F9F8),
    surface: Color(0xFFFFFFFF),
    onSurface: Color(0xFF1C1B1F),
    error: Color(0xFFB3261E),
    success: Color(0xFF2E7D32),
    warning: Color(0xFFED8B00),
    streak: Color(0xFFFF7043),
  );

  static const dark = AppPalette(
    primary: Color(0xFF6FCFB8),
    onPrimary: Color(0xFF00382D),
    secondary: Color(0xFF9DB8FF),
    background: Color(0xFF121413),
    surface: Color(0xFF1C1F1E),
    onSurface: Color(0xFFE6E1E5),
    error: Color(0xFFF2B8B5),
    success: Color(0xFF81C784),
    warning: Color(0xFFFFB74D),
    streak: Color(0xFFFF8A65),
  );
}
