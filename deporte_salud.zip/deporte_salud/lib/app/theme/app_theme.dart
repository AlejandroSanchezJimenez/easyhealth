import 'package:flutter/material.dart';
import 'app_colors_ext.dart';
import 'app_palette.dart';

class AppTheme {
  static ThemeData build(AppPalette p, Brightness brightness) {
    final scheme = ColorScheme(
      brightness: brightness,
      primary: p.primary,
      onPrimary: p.onPrimary,
      secondary: p.secondary,
      onSecondary: p.onPrimary,
      error: p.error,
      onError: p.onPrimary,
      surface: p.surface,
      onSurface: p.onSurface,
    );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: p.background,
      extensions: [AppColorsExt.from(p)],
    );
  }

  static final light = build(AppPalette.light, Brightness.light);
  static final dark = build(AppPalette.dark, Brightness.dark);
}
