import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../shared/widgets/async_view.dart';
import '../diseases_providers.dart';

class ExplorePage extends ConsumerWidget {
  const ExplorePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) => SafeArea(
        child: AsyncView(
          value: ref.watch(diseasesProvider),
          builder: (list) => list.isEmpty
              ? const Center(child: Text('Aún no hay enfermedades disponibles'))
              : ListView(
                  children: [
                    for (final d in list)
                      ListTile(
                        title: Text(d.name),
                        subtitle: Text(d.shortDescription),
                        trailing: const Icon(Icons.chevron_right),
                        // TODO Fase 3: pantalla de detalle (ejercicios + clases + descarga).
                      ),
                  ],
                ),
        ),
      );
}
