import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../auth/auth_providers.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    return SafeArea(
      child: ListView(children: [
        ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(user?.displayName ?? user?.email ?? ''),
          subtitle: Text(user?.role.name ?? ''),
        ),
        const ListTile(leading: Icon(Icons.download_done), title: Text('Contenido sin conexión')),
        if (user?.role.canManageContent ?? false)
          ListTile(
            leading: const Icon(Icons.school),
            title: const Text('Panel de maestro'),
            onTap: () => context.push('/teacher'),
          ),
        ListTile(
          leading: const Icon(Icons.logout),
          title: const Text('Cerrar sesión'),
          onTap: () => ref.read(authRepositoryProvider).signOut(),
        ),
      ]),
    );
  }
}
