import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/theme/app_colors_ext.dart';
import '../../../core/providers.dart';
import '../../../shared/widgets/async_view.dart';
import '../../videos/videos_providers.dart';
import '../streak_providers.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final online = ref.watch(onlineProvider).valueOrNull ?? true;
    final downloaded = ref.watch(offlineLibraryProvider).all().values.toList();
    return SafeArea(
      child: ListView(padding: const EdgeInsets.all(16), children: [
        AsyncView(
          value: ref.watch(streakStatsProvider),
          builder: (s) => Card(
            child: ListTile(
              leading: Icon(Icons.local_fire_department, color: context.appColors.streak, size: 36),
              title: Text('${s.currentStreak} días de racha'),
              subtitle: Text('Récord: ${s.longestStreak} · Total: ${s.totalExerciseDays} días'),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: ListTile(
            title: Text('Entrenamiento de hoy'),
            subtitle: Text('Pendiente de implementar en la Fase 3'),
          ),
        ),
        // Modo emergencia: solo aparece sin conexión.
        if (!online) ...[
          const SizedBox(height: 12),
          const ListTile(
            leading: Icon(Icons.cloud_off),
            title: Text('Sin conexión'),
            subtitle: Text('Puedes usar las clases que descargaste'),
          ),
          for (final w in downloaded)
            ListTile(
              leading: Icon(Icons.download_done, color: context.appColors.success),
              title: Text(w.workout.name),
              // TODO Fase 4: abrir reproductor con w.videoPaths
            ),
        ],
      ]),
    );
  }
}
