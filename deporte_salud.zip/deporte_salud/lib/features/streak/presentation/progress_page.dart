import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../shared/widgets/async_view.dart';
import '../streak_providers.dart';

class ProgressPage extends ConsumerWidget {
  const ProgressPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) => SafeArea(
        child: AsyncView(
          value: ref.watch(streakStatsProvider),
          builder: (s) => ListView(padding: const EdgeInsets.all(16), children: [
            ListTile(title: const Text('Racha actual'), trailing: Text('${s.currentStreak}')),
            ListTile(title: const Text('Racha más larga'), trailing: Text('${s.longestStreak}')),
            ListTile(title: const Text('Días activos'), trailing: Text('${s.totalExerciseDays}')),
            ListTile(
                title: const Text('Tiempo total'),
                trailing: Text('${(s.totalExerciseSeconds / 60).round()} min')),
            // TODO Fase 5: calendario e historial.
          ]),
        ),
      );
}
