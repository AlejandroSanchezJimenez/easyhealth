import 'package:flutter/material.dart';

/// Área de maestro, separada de la experiencia del usuario normal.
/// Fase 2: CRUD con ContentRemote.save / setStatus (borrador -> publicado).
class TeacherPage extends StatelessWidget {
  const TeacherPage({super.key});

  @override
  Widget build(BuildContext context) {
    const sections = [
      (Icons.dashboard, 'Dashboard'),
      (Icons.healing, 'Enfermedades'),
      (Icons.fitness_center, 'Ejercicios'),
      (Icons.videocam, 'Vídeos'),
      (Icons.class_, 'Clases'),
      (Icons.person, 'Perfil'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Panel de maestro')),
      body: ListView(children: [
        for (final s in sections) ListTile(leading: Icon(s.$1), title: Text(s.$2)),
      ]),
    );
  }
}
