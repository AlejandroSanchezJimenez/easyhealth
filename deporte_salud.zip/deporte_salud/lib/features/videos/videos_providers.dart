import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/firestore_paths.dart';
import '../../core/providers.dart';
import '../../shared/data/content_repository.dart';
import 'data/offline_library.dart';
import 'data/workout_downloader.dart';
import 'domain/video_meta.dart';

final videoRemoteProvider = Provider((ref) => ContentRemote<VideoMeta>(
    ref.watch(firestoreProvider), FirestorePaths.videos, VideoMeta.fromMap, (v) => v.toMap()));

final videosProvider =
    StreamProvider<List<VideoMeta>>((ref) => ref.watch(videoRemoteProvider).watchPublished());

final offlineLibraryProvider = Provider((ref) => OfflineLibrary(ref.watch(sharedPrefsProvider)));

final workoutDownloaderProvider = Provider(
    (ref) => WorkoutDownloader(ref.watch(downloadManagerProvider), ref.watch(offlineLibraryProvider)));
