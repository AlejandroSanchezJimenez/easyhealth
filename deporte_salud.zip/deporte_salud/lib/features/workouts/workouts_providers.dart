import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/config.dart';
import '../../core/constants/firestore_paths.dart';
import '../../core/providers.dart';
import '../../core/utils/date_key.dart';
import '../../shared/data/content_repository.dart';
import '../auth/auth_providers.dart';
import '../exercises/domain/exercise.dart';
import '../exercises/exercises_providers.dart';
import '../streak/streak_providers.dart';
import 'domain/daily_workout_generator.dart';
import 'domain/workout.dart';

final workoutRemoteProvider = Provider((ref) => ContentRemote<Workout>(
    ref.watch(firestoreProvider), FirestorePaths.workouts, Workout.fromMap, (w) => w.toMap()));

final workoutsProvider =
    StreamProvider<List<Workout>>((ref) => ref.watch(workoutRemoteProvider).watchPublished());

/// Entrenamiento aleatorio del día. Determinista por (usuario, enfermedad, fecha).
/// Ignora lo hecho HOY al excluir recientes, para que no cambie durante el día.
final dailyExercisesProvider =
    Provider.family<AsyncValue<List<Exercise>>, String>((ref, diseaseId) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return const AsyncValue.data([]);
  final today = dateKey(DateTime.now());
  final from = dateKey(DateTime.now().subtract(const Duration(days: AppConfig.recentDaysToAvoid)));
  final sessions = ref.watch(sessionsProvider).valueOrNull ?? const [];
  final recent = sessions
      .where((s) => s.kind == 'exercise' && s.dateKey.compareTo(from) >= 0 && s.dateKey != today)
      .map((s) => s.refId)
      .toSet();

  return ref.watch(exercisesByDiseaseProvider(diseaseId)).whenData((list) {
    final byId = {for (final e in list) e.id: e};
    final ids = DailyWorkoutGenerator.generate(
      uid: user.uid,
      diseaseId: diseaseId,
      dateKey: today,
      availableIds: byId.keys.toList(),
      recentIds: recent,
      count: AppConfig.dailyWorkoutSize,
    );
    return ids.map((i) => byId[i]!).toList();
  });
});
