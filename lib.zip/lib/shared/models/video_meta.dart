import 'package:cloud_firestore/cloud_firestore.dart';

class VideoMeta {
  final String id;
  final String title;
  final String url;
  final String? thumbnailUrl;
  final String? description;
  final String? createdBy;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String status;

  const VideoMeta({
    required this.id,
    required this.title,
    required this.url,
    this.thumbnailUrl,
    this.description,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
    this.status = 'published',
  });

  factory VideoMeta.fromFirestore(
    DocumentSnapshot<Map<String, dynamic>> doc,
  ) {
    final data = doc.data() ?? {};

    return VideoMeta(
      id: doc.id,
      title: data['title'] as String? ?? '',
      url: data['url'] as String? ?? '',
      thumbnailUrl: data['thumbnailUrl'] as String?,
      description: data['description'] as String?,
      createdBy: data['createdBy'] as String?,
      createdAt: _date(data['createdAt']),
      updatedAt: _date(data['updatedAt']),
      status: data['status'] as String? ?? 'published',
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'url': url,
      'thumbnailUrl': thumbnailUrl,
      'description': description,
      'createdBy': createdBy,
      'createdAt': createdAt == null
          ? FieldValue.serverTimestamp()
          : Timestamp.fromDate(createdAt!),
      'updatedAt': updatedAt == null
          ? FieldValue.serverTimestamp()
          : Timestamp.fromDate(updatedAt!),
      'status': status,
    };
  }

  static DateTime? _date(dynamic value) {
    if (value is Timestamp) {
      return value.toDate();
    }

    if (value is DateTime) {
      return value;
    }

    return null;
  }
}
